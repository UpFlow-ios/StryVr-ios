

//  //
//  HomeView.swift
//  StryVr
//
//  Created by Joe Dormond on 2/24/25.
//

import SwiftUI
import Firebase

struct HomeView: View {
    @StateObject private var viewModel = HomeViewModel()
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    
                    // Greeting & Progress
                    VStack(alignment: .leading) {
                        Text("Welcome Back, \(viewModel.userName) 👋")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                        
                        ProgressBarView(progress: viewModel.skillProgress)
                        
                        Text("Skill Progress: \(Int(viewModel.skillProgress * 100))%")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    .padding()
                    
                    // Trending Skills
                    Text("🔥 Trending Skills")
                        .font(.title2)
                        .fontWeight(.bold)
                        .padding(.horizontal)
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(viewModel.trendingSkills, id: \.self) { skill in
                                SkillTagView(skill: skill)
                            }
                        }
                        .padding(.horizontal)
                    }
                    
                    // Mentor Recommendations
                    Text("👨‍🏫 Recommended Mentors")
                        .font(.title2)
                        .fontWeight(.bold)
                        .padding(.horizontal)
                    
                    MentorListView(mentors: viewModel.mentors)
                    
                    // Actions
                    HStack(spacing: 20) {
                        NavigationLink(destination: LearningPathsView()) {
                            CustomButton(title: "Start Learning", icon: "book.fill")
                        }
                        NavigationLink(destination: MentorSessionListView()) {
                            CustomButton(title: "Find a Mentor", icon: "person.fill")
                        }
                        NavigationLink(destination: ReportsView()) {
                            CustomButton(title: "View Reports", icon: "chart.bar.fill")
                        }
                    }
                    .padding()
                    
                }
                .padding(.top)
            }
            .navigationTitle("Dashboard")
            .onAppear {
                viewModel.fetchUserData()
                viewModel.fetchTrendingSkills()
                viewModel.fetchMentors()
            }
        }
    }
}

// MARK: - Preview
struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}

//  HomeView.swift
//  StryVr
//
//  Created by Joe Dormond on 2/24/25.
//

