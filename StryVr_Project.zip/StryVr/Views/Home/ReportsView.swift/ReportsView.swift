//
//  Untitled.swift
//  StryVr
//
//  Created by Joe Dormond on 2/24/25.
//
import SwiftUI

struct ReportsView: View {
    @State private var reports: [Report] = [
        Report(title: "February Skill Analysis", score: 85),
        Report(title: "SwiftUI Proficiency", score: 90),
        Report(title: "Firebase Security Assessment", score: 75)
    ]

    var body: some View {
        NavigationView {
            VStack {
                Text("Reports")
                    .font(.largeTitle)
                    .bold()
                    .padding(.top, 20)
                
                List(reports) { report in
                    ReportCard(report: report)
                }
                .listStyle(PlainListStyle())
            }
            .navigationTitle("Skill Reports")
        }
    }
}

struct Report: Identifiable {
    let id = UUID()
    let title: String
    let score: Int
}

struct ReportCard: View {
    let report: Report

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(report.title)
                .font(.headline)
            
            HStack {
                Text("Score: \(report.score)%")
                    .font(.subheadline)
                    .foregroundColor(.blue)
                
                Spacer()
                
                ProgressBarView(progress: CGFloat(report.score))
                    .frame(width: 100, height: 10)
            }
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(UIColor.systemBackground)).shadow(radius: 2))
    }
}

struct ReportsView_Previews: PreviewProvider {
    static var previews: some View {
        ReportsView()
    }
}

