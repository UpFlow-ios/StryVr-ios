//
//  DashboardView.swift
//  StryVr
//
//  Created by Joe Dormond on 2/23/25.
//
import SwiftUI
import Firebase

struct DashboardView: View {
    @State private var userName: String = "Loading..."
    @State private var profileImageURL: String = ""
    @State private var skillProgress: [String: Double] = [:] // Stores skill progress

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    
                    // User Profile Section
                    HStack {
                        AsyncImage(url: URL(string: profileImageURL)) { image in
                            image.resizable().scaledToFill()
                        } placeholder: {
                            Image(systemName: "person.crop.circle.fill").resizable()
                        }
                        .frame(width: 80, height: 80)
                        .clipShape(Circle())
                        .padding()

                        VStack(alignment: .leading) {
                            Text("Welcome, \(userName)")
                                .font(.title2)
                                .bold()
                            
                            Text("Let's build your skills today!")
                                .foregroundColor(.gray)
                        }
                    }
                    
                    Divider()
                    
                    // Skill Progress Section
                    VStack(alignment: .leading) {
                        Text("Your Skill Progress")
                            .font(.headline)

                        ForEach(skillProgress.sorted(by: { $0.value > $1.value }), id: \.key) { skill, progress in
                            HStack {
                                Text(skill)
                                    .font(.subheadline)
                                Spacer()
                                ProgressView(value: progress, total: 100)
                                    .progressViewStyle(LinearProgressViewStyle())
                            }
                        }
                    }
                    .padding()

                    Divider()
                    
                    // Learning Paths Section
                    VStack(alignment: .leading) {
                        Text("Your Learning Paths")
                            .font(.headline)
                        // Placeholder for learning paths
                        Text("Coming soon...")
                            .foregroundColor(.gray)
                    }
                    .padding()

                    Divider()
                    
                    // Community & Mentors
                    VStack(alignment: .leading) {
                        Text("Explore Mentors & Community")
                            .font(.headline)
                        // Placeholder for mentors section
                        Text("Top mentors and trending discussions will appear here!")
                            .foregroundColor(.gray)
                    }
                    .padding()
                    
                }
                .padding()
            }
            .navigationTitle("Dashboard")
        }
        .onAppear {
            fetchUserData()
        }
    }

    // Fetch user data from Firebase
    func fetchUserData() {
        let userID = Auth.auth().currentUser?.uid ?? ""

        if userID.isEmpty { return }

        let db = Firestore.firestore()
        db.collection("Users").document(userID).getDocument { document, error in
            if let document = document, document.exists {
                let data = document.data()
                self.userName = data?["name"] as? String ?? "User"
                self.profileImageURL = data?["profileImage"] as? String ?? ""
                self.skillProgress = data?["skillProgress"] as? [String: Double] ?? [:]
            }
        }
    }
}

struct DashboardView_Previews: PreviewProvider {
    static var previews: some View {
        DashboardView()
    }
}

